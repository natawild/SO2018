#ifndef __READL_H__
#define __READL_H__

//ssize_t readln(int fildes, void *buf, size_t nbyte);
ssize_t readln(int fildes, void *buf, size_t nbyte);

#endif 
